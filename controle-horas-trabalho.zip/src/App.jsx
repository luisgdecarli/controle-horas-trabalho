import ControleHoras from "./ControleHoras";

export default function App() {
  return <ControleHoras />;
}
