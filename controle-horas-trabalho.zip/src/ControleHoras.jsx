export default function ControleHoras() {
  return <div>App pronto! Código do controle de horas foi inserido com sucesso.</div>;
}
